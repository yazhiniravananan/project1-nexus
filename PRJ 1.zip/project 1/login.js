// login.js
function generateStrongPassword(length) {
  const uppercaseChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  const lowercaseChars = 'abcdefghijklmnopqrstuvwxyz';
  const numberChars = '0123456789';
  const specialChars = '!@#$%^&*()-_=+[]{}|;:,.<>?/';

  const allChars = uppercaseChars + lowercaseChars + numberChars + specialChars;

  let password = '';
  
  for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * allChars.length);
      password += allChars.charAt(randomIndex);
  }

  return password;
}


const strongPassword = generateStrongPassword(12);
console.log(strongPassword);
function login() {
  // Fetch values from the input fields
  var email = document.getElementById("email").value;
  var password = document.getElementById("password").value;

  if (email.trim() === "" || password.trim() === "") {
    alert("Please enter both email and password.");
    return;
  }
  
  alert("Login successful! Redirecting to the dashboard...");
}


