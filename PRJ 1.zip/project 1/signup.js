function signup() {

    var fullName = document.getElementById("fullname").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;
  

    if (fullName.trim() === "" || email.trim() === "" || password.trim() === "" || confirmPassword.trim() === "") {
      alert("Please fill in all the fields.");
      return;
    }
  
     if (password !== confirmPassword) {
      alert("Passwords do not match.");
      return;
    }

    alert("Sign Up successful! Redirecting to the login page...");
    }
   
  